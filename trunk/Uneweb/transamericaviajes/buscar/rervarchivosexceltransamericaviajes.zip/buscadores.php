
	<?php include("conexion.php"); ?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>



<title></title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<link href="admin/botonera/css-styles/style.css" type="text/css" rel="stylesheet"/>

<script src="admin/botonera/scripts/images.js" type="text/javascript"></script>

<script src="Scripts/swfobject_modified.js" type="text/javascript"></script>



<script type="text/javascript">
		function validateCedulaAndSubmit(formToValidate){
			var doSubmit = true;
			var cedulaValue = formToValidate.cedula.value;
			
			if(cedulaValue == null || cedulaValue == ''){
				alert('Disculpe debe indicar un numero de cedula');
				doSubmit = false;
			}

			if (doSubmit) {
				formToValidate.submitButton.disabled = true;
				formToValidate.submit();
			}
		}

		function validateLocalizadorAndSubmit(formToValidate){
			var doSubmit = true;
			var localizadorValue = formToValidate.localizador.value;
			
			if(localizadorValue == null || localizadorValue == ''){
				alert('Disculpe debe indicar un numero de localizador');
				doSubmit = false;
			}

			if (doSubmit) {
				formToValidate.submitButton.disabled = true;
				formToValidate.submit();
			}
		}
	</script>
<link href="scripts/estilos.css" rel="stylesheet" type="text/css" />

<!-- jQuery -->

<script type="text/javascript" src="scripts/jquery-1.4.2.min.js"></script>

<!-- Slide -->

<script type="text/javascript" src="scripts/jquery.cycle.all.latest.js"></script>

<!-- Acordion -->

<script type="text/javascript" src="scripts/jquery.dimensions.js"></script>

<script type="text/javascript" src="scripts/jquery.accordion.js"></script>

<!-- Scripts -->

<link rel="stylesheet" href="scripts/nivo/nivo-slider.css" type="text/css" media="screen" />

<script type="text/javascript" src="scripts/scripts.js"></script>



<!-- <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script> -->


<script type='text/javascript'>

    // Eventos de recarga

    $(document).ready(function() {

        

        // Select de titulos

        $('#titulos').change(function() {

            // Capturo el value del option de select de titulos

            titulo = $.trim($('#titulos option:selected').attr('value'));

            
            // Mando a la consola de firebug para ver que valor obtuvo (debugging)
            //if (typeof console != "undefined") {console.log(titulo)};

            

            // Recargo la p�gina con los datos

            window.location = 'buscar.php?titulo=' + titulo;

            

        });

        

        // Select de puerto

        $('#puerto').change(function() {

            // Capturo los datos 
            puerto = $.trim($('#puerto option:selected').attr('value'));
            

            // Recargo la p�gina con los datos
            window.location = 'buscar.php?puerto=' + puerto;

            

        });

        

        // Select de destino

        $('#destinos').change(function() {

            // Capturo los datos 
            destino = $.trim($('#destinos option:selected').attr('value'));

            

            // Recargo la p�gina con los datos

            window.location = 'buscar.php?destino=' + destino;

            

        });

        

        // Select de naviera

        $('#navieras').change(function() {

            naviera = $.trim($('#navieras option:selected').attr('value'));

            

            // Recargo la p�gina con los datos

            window.location = 'buscar.php?naviera=' + naviera;

            

        });

        

        // Select de precio

        $('#precio').change(function() {

            // Capturo los datos de los 2 select necesarios
            precio = $.trim($('#precio option:selected').attr('value'));

            

            // Recargo la p�gina con los datos

            window.location = 'buscar.php?precio=' + precio;

            

        });

        

        

        // Select de fecha

        $('#fecha').change(function() {

            // Capturo los datos de los 2 select necesarios
            fecha = $.trim($('#fecha option:selected').attr('value'));

            

            // Recargo la p�gina con los datos
            window.location = 'buscar.php?fecha=' + fecha;

            

        });

        

        // Comportamiento del boton de buscar

        $('#filtro').submit(function() {
            alert('Debe seleccionar algun campo del buscador');
            return false;
        });

    });

</script>


<script type='text/javascript'>
    // Eventos de recarga
    $(document).ready(function() {
        
        // Select de titulos
        $('#titulos').change(function() {
            // Capturo el value del option de select de titulos
            titulo = $.trim($('#titulos option:selected').attr('value'));
            
            
            // Recargo la p�gina con los datos
            window.location = 'buscar.php?titulo=' + titulo;
            
        });
        
        // Select de precio
        $('#precio').change(function() {
            // Capturo los datos
            precio = $.trim($('#precio option:selected').attr('value'));
            
            // Recargo la p�gina con los datos
            window.location = 'buscar.php?precio=' + precio;
            
        });
        
        // Select de duracion
        $('#duracion').change(function() {
            // Capturo los datos
            duracion = $.trim($('#duracion option:selected').attr('value'));
            
            // Recargo la p�gina con los datos
            window.location = 'buscar.php?duracion=' + duracion;
            
        });
        
        
        // Select de  itinerario
        $('#itinerario').change(function() {
            // Capturo los datos
            itinerario = $.trim($('#itinerario option:selected').attr('value'));
            
            // Recargo la p�gina con los datos
            window.location = 'buscar.php?itinerario=' + escape(itinerario);
            
        });
      
        
          // Comportamiento del boton de buscar

        $('#filtro').submit(function() {
            alert('Debe seleccionar algun campo del buscador');
            return false;
        });
    });
    
    
</script>






<style type="text/css">

<!--

body {

	margin-left: 0px;

	margin-top: 0px;

	margin-right: 0px;

	margin-bottom: 0px;

}

-->

</style>



</head>



<body>

    <table width="1034" border="0" align="center" cellpadding="0" cellspacing="0" style="background: <?php echo $row2[color]; ?>">

  <tr>

    <td colspan="3"><table align="center" cellpadding="0" border="0" cellspacing="0" width="100%">	

			<tr>

            	<td width="25%"  valign="bottom">

			

				     



				</td>

               <td valign="bottom"></td>

            </tr>

        </table></td>

    </tr>          

  <tr>

	<td colspan="4">
<br />

	 			    	    

	

		<!-- Espacio para el flash, sustituir por el verdadero -->

	</td>

  </tr>

  <tr>

    <td colspan="4" align="right" >

        <!-- Espacio para la Botonera Principal -->
<br /><br />

      

        <!-- Espacio para la Botonera Principal -->

    </td>

  </tr>

  <tr>

    <td colspan="4" >

    	<div style="height:5px;"></div>

    	<!-- Espacio para las subsecciones -->

      
   		<!-- Espacio para las categorias -->

   	  <div style="height:5px;"></div>

    </td>

  </tr>

  <tr>

    <td width="68%" valign="top" align="center" style="padding-left: 15px; padding-right: 15px;">

		<!-- Espacio para el contenido -->

		

	
			<tr>

				<td colspan="2" align="center" valign="top">&nbsp;</td>

			</tr>



	


			<tr>

				<td align='left' colspan='4' style="padding-left: 36px;">

					<!-- Contador de Paginas -->

					<div style='height: 20px;'></div>
	        <div style='height: 20px;'></div>

					<!-- Contador de Paginas -->

				</td>

			</tr>

		</table>
    <div align="center">
      <div style='height: 200px;'></div>

				
				

</div>	

			

			

	

	

		

		

		

		<!-- Espacio para el contenido -->

	</td>

  <td width="32%" valign="top" align="center">

		<!-- Espacio para los banners -->

		<div align="center">





        <form action="?b=1&mira=53" method="get" name="filtro" id="filtro" style="margin:0 0 0 0">

  <div style="background-color:#1997e1; height:25px; padding-top:10px" class="txt_1" align="center">

    BUSCADOR DE CRUCEROS

  </div>

  <div style=" background-color:#efefef; padding-right:8px; height:250px">

    <div style=" height:10px"></div>

    

    <select name="titulos" id="titulos" style="font-size:14px;color:#0351a0; width:175px">

        <option value='0' selected="selected">Cualquier paquete</option>

    <?php   

        $sql="SELECT DISTINCT titulo from programas WHERE seccion=53 AND titulo IS NOT NULL AND titulo !='' ORDER BY titulo";
        $tran=mysql_query($sql,$conexion); 
        while($fila=mysql_fetch_array($tran)){  

    ?>

        <option value="<?php echo $fila['titulo']; ?>" >

            <?php echo $fila['titulo']; ?>

        </option>

    <?php 

          

          //echo mysql_error();

          

        }

    ?>

    </select>	  

				  

    <div style=" height:10px"></div>

    

    <select name="puerto" id="puerto" style="font-size:14px;color:#0351a0; width:175px">

        <option value='0'>Cualquier puerto</option>

    <?php   
        
        $sql="SELECT DISTINCT puertoSalida from programas WHERE seccion=53 AND puertoSalida IS NOT NULL and puertoSalida != '' ORDER By puertoSalida";
        $tran=mysql_query($sql,$conexion); 
        while ($fila=mysql_fetch_array($tran)){  

    ?>

        <option value="<?php print $fila['puertoSalida']; ?>">
            <?php print $fila['puertoSalida']; ?>
        </option> 

    <?php 

        }


    ?>		   

    </select>

	

    <div style=" height:10px"></div>

    

    <select name="destinos" id="destinos" style="font-size:14px;color:#0351a0; width:175px">

        <option value='0'>Cualquier destino</option>

        
    <?php
        
        $sql="SELECT DISTINCT destino from programas WHERE seccion=53 AND destino IS NOT NULL and destino != '' ORDER by destino";
        $tran=mysql_query($sql,$conexion); 
        while ($fila=mysql_fetch_array($tran)){  

    ?>

        <option value="<?php print $fila['destino']; ?>">

            <?php print $fila['destino']; ?>

        </option> 

    <?php 

        }

    ?>		   

    </select>

	

    <div style=" height:10px"></div>

    

    <select name="navieras" id="navieras" style="font-size:14px;color:#0351a0; width:175px">

        <option value='0'>Cualquier naviera</option>

    <?php   
        $sql="SELECT DISTINCT naviera from programas WHERE seccion=53 AND naviera IS NOT NULL and naviera != '' ORDER by naviera";
        $tran=mysql_query($sql,$conexion); 
        while ($fila=mysql_fetch_array($tran)){  

    ?>

        <option value="<?php print $fila['naviera']; ?>">

            <?php print $fila['naviera']; ?>

        </option> 

    <?php 

        }

    ?>

    </select>

    

    <div style=" height:10px"></div>

    

    <select name="precio" id="precio" style="font-size:14px;color:#0351a0; width:175px">

        <option value='0'>Cualquier precio</option>

    <?php   
        $sql="SELECT DISTINCT precio from programas WHERE seccion=53 AND precio IS NOT NULL and precio != '' ORDER by precio";
        $tran=mysql_query($sql,$conexion); 
        while ($fila=mysql_fetch_array($tran)) {  

    ?>

        <option value="<?php print $fila['precio']; ?>">

            <?php print $fila['precio']; ?>

        </option> 

    <?php 

        }

    ?>		   

    </select>

    

    

    <div style=" height:10px"></div>

    

    <select name="fecha" id="fecha" style="font-size:14px;color:#0351a0; width:175px">

        <option value='0'>Cualquier fecha</option>

    <?php   
        $sql="SELECT DISTINCT fecha from programas WHERE seccion=53 AND fecha IS NOT NULL and fecha != '' ORDER by fecha";
        $tran=mysql_query($sql,$conexion); 
        while ($fila=mysql_fetch_array($tran)) {  

    ?>

        <option value="<?php print $fila['fecha']; ?>">

            <?php print $fila['fecha']; ?>

        </option> 

    <?php 

        }
    
    ?>		   

    </select>


    

    

    <div style="width:175px; height:20px;font-size:14px; font-family:Arial, Helvetica, sans-serif;color:#0351a0; margin: 10 auto 0 auto; display:none" align="left">

      <input name="param6" value="69" type="checkbox" />

      S�lo Sin Visa 

    </div>

    <div style="clear:both"></div>

    <div style=" height:10px"></div>
  </div>

  <input name="elemento_comienzo" value="0" type="hidden" />

</form>
<br />
     <div align="center" ></div>
     <form action="?b=1&mira=70" method="get" name="filtro" id="filtro" style="margin:0 0 0 0">
       
       <div style="background-color:#1997e1; height:25px; padding-top:10px" class="txt_1" align="center">

    BUSCADOR DE CIRCUITOS</div>

  <div style=" background-color:#efefef; padding-right:8px; height:250px">

    <div style=" height:10px"></div>

    

    <select name="titulos" id="titulos" style="font-size:14px;color:#0351a0; width:175px">

        <option value='0'>Cualquier paquete</option>

    <?php   

        $sql="SELECT DISTINCT titulo from programas WHERE seccion=70 AND titulo IS NOT NULL AND titulo !='' ORDER BY titulo";
        $tran=mysql_query($sql,$conexion);
        while($fila=mysql_fetch_array($tran)){  

    ?>

        <option value="<?php echo $fila['titulo']; ?>">

            <?php echo $fila['titulo']; ?>

        </option>

    <?php 


        }

    ?>

    </select>	  

				  

    <div style=" height:10px"></div>

    

    <select name="precio" id="precio" style="font-size:14px;color:#0351a0; width:175px">

        <option value='0'>Cualquier precio</option>

    <?php   

        $sql="SELECT DISTINCT precio from programas WHERE seccion=70 AND precio IS NOT NULL AND precio !='' ORDER BY precio";
        $tran=mysql_query($sql,$conexion);
        while($fila=mysql_fetch_array($tran)){  

    ?>
        <option value="<?php print $fila['precio']; ?>" >

            <?php print $fila['precio']; ?>

        </option> 

    <?php 

        }

    ?>		   

    </select>

	

    <div style=" height:10px"></div>

    

    <select name="duracion" id="duracion" style="font-size:14px;color:#0351a0; width:175px">

        <option value='0'>Cualquier duracion</option>

    <?php   

        $sql="SELECT DISTINCT duracion from programas WHERE seccion=70 AND duracion IS NOT NULL AND duracion !='' ORDER BY duracion";
        $tran=mysql_query($sql,$conexion);
        while($fila=mysql_fetch_array($tran)){  

    ?>

        <option value="<?php print $fila['duracion']; ?>" >

            <?php print $fila['duracion']; ?>

        </option> 

    <?php 

        }

    ?>		   

    </select>

	

    <div style=" height:10px"></div>

    

    <select name="itinerario" id="itinerario" style="font-size:14px;color:#0351a0; width:175px">

        <option value='0'>Cualquier itinerario</option>

    <?php   

        $sql="SELECT DISTINCT itinerario from programas WHERE seccion=70 AND itinerario IS NOT NULL AND itinerario !='' ORDER BY itinerario";
        $tran=mysql_query($sql,$conexion);
        while($fila=mysql_fetch_array($tran)){  

    ?>

        <option value="<?php print $fila['itinerario']; ?>">

            <?php print $fila['itinerario']; ?>

        </option> 

		   

    </select>

     

    <div style="width:175px; height:20px;font-size:14px; font-family:Arial, Helvetica, sans-serif;color:#0351a0; margin: 10 auto 0 auto; display:none" align="left">

      <input name="param6" value="69" type="checkbox" />

      S�lo Sin Visa 

    </div>

    <div style="clear:both"></div>

    <div style=" height:10px"></div>
  </div>

  <input name="elemento_comienzo" value="0" type="hidden" />

</form>
<br />
     <div align="center" ></div>



   <div style="height: 25px;"></div>
      

      
    <div style="height: 20px;"></div>
            
			

            

				        

	        

	        

      	</div>

      	<!-- Espacio para los banners -->

	</td>

  </tr>

</table>

</div>

</body>

</html>

